﻿using MemberApi.DAL.Data;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace MemberApi.DAL.Repositories
{
    public abstract class RepositoryBase<TEntity> : IRepositoryBase<TEntity> where TEntity : class, new()
    {
        protected readonly MemberContext MemberContext;

        public RepositoryBase(MemberContext memberContext)
        {
            MemberContext = memberContext;
        }
        public IQueryable<TEntity> FindByCondition(Expression<Func<TEntity, bool>> expression)
        {
            return MemberContext.Set<TEntity>().Where(expression).AsNoTracking();
        }
        public IEnumerable<TEntity> GetAll()
        {
            try
            {
                return MemberContext.Set<TEntity>();
            }
            catch (Exception ex)
            {
                throw new Exception($"Couldn't retrieve entities: {ex.Message}");
            }
        }
        public TEntity Create(TEntity entity)
        {
            if (entity == null)
            {
                throw new ArgumentNullException($"{nameof(Create)} entity must not be null");
            }

            try
            {
                MemberContext.Add(entity);
                MemberContext.SaveChanges();

                return entity;
            }
            catch (Exception ex)
            {
                throw new Exception($"{nameof(entity)} could not be saved: {ex.Message}");
            }
        }


        public TEntity Update(TEntity entity)
        {
            if (entity == null)
            {
                throw new ArgumentNullException($"{nameof(Update)} entity must not be null");
            }

            try
            {
                MemberContext.Update(entity);
                MemberContext.SaveChanges();

                return entity;
            }
            catch (Exception ex)
            {
                throw new Exception($"{nameof(entity)} could not be updated {ex.Message}");
            }
        }

        public void Delete(TEntity entity)
        {
            try
            {
                MemberContext.Remove(entity);
                MemberContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception($"Couldn't remove entities: {ex.Message}");
            }
        }
    }
}

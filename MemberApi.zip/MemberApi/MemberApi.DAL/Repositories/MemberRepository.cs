﻿using MemberApi.DAL.Data;
using MemberApi.DAL.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MemberApi.DAL.Repositories
{
    public class MemberRepository : RepositoryBase<Member>, IMemberRepository
    {
        public MemberRepository(MemberContext memberContext) : base(memberContext)
        {
        }
        public Member GetMemberById(int Id)
        {
            try
            {
                return FindByCondition(m => m.Id.Equals(Id)).FirstOrDefault();
            }
            catch (Exception ex)
            {
                throw new Exception($"Couldn't retrieve entities: {ex.Message}");
            }
        }
    }
}

﻿using MemberApi.DAL.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MemberApi.DAL.Mapping
{
    internal class MemberTableMapping : IEntityTypeConfiguration<Member>
    {
        public void Configure(EntityTypeBuilder<Member> builder)
        {

            builder.Property<int>("Id")
                .ValueGeneratedOnAdd()
                .HasColumnType("int")
                .HasAnnotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn);

            builder.Property<string>("FirstName")
                .HasColumnType("varchar(50)").IsRequired();

            builder.Property<string>("LastName")
                .HasColumnType("varchar(50)").IsRequired();

            builder.Property<string>("MiddelName")
                .HasColumnType("nvarchar(50)");

            builder.HasKey("Id");

            builder.Property<string>("Mail")
                .HasColumnType("varchar(50)").IsRequired();

            builder.Property<string>("Mobile")
                .HasColumnType("varchar(10)").IsRequired();

            builder.ToTable("Member");

        }
    }
}

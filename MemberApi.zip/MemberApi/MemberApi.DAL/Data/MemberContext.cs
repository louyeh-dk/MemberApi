﻿using MemberApi.DAL.Entities;
using MemberApi.DAL.Mapping;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MemberApi.DAL.Data
{
    public class MemberContext : DbContext
    {
        public DbSet<Member> Members { get; set; }

        public MemberContext(DbContextOptions<MemberContext> options)
            : base(options)
        {
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new MemberTableMapping());
        }



    }
}

﻿using MemberApi.Dto;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace MemberApiClient.Controllers
{
    public class MemberApiClientController : Controller
    {
        private readonly IConfiguration configuration;
        private string apiBaseAddress;
        public MemberApiClientController(IConfiguration configuration)
        {
            this.configuration = configuration;
            apiBaseAddress = configuration.GetSection("ApiBaseAddress").Value;
        }
        public async Task<IActionResult> Index()
        {
            List<MemberDtoRead> memberList = new List<MemberDtoRead>();
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync(apiBaseAddress))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    memberList = JsonConvert.DeserializeObject<List<MemberDtoRead>>(apiResponse);
                }
            }
            return View(memberList);
        }


        public ViewResult AddMember() => View();

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddMember(MemberDtoWrite memberDtoWrite)
        {
            if (ModelState.IsValid)
            {
                MemberDtoWrite confirmedResult = new MemberDtoWrite();
                try 
                {
                    using (var httpClient = new HttpClient())
                    {
                        StringContent content = new StringContent(JsonConvert.SerializeObject(memberDtoWrite), Encoding.UTF8, "application/json");
                        using (var response = await httpClient.PostAsync(apiBaseAddress, content))
                        {
                            string apiResponse = await response.Content.ReadAsStringAsync();
                            confirmedResult = JsonConvert.DeserializeObject<MemberDtoWrite>(apiResponse);
                        }
                    }
                }
                catch 
                {
                    return View();                
                }
            }
            return RedirectToAction(nameof(Index));
        }
        public async Task<IActionResult> UpdateMember(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            MemberDtoWrite memberDtoWrite = new MemberDtoWrite();
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync(apiBaseAddress + id))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    memberDtoWrite = JsonConvert.DeserializeObject<MemberDtoWrite>(apiResponse);
                }
            }
            return View(memberDtoWrite);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateMember(int id, MemberDtoWrite memberDtoWrite)
        {
            MemberDtoWrite confirmedWrite = new MemberDtoWrite();
            if (ModelState.IsValid)
            {
                try
                {
                    using (var httpClient = new HttpClient())
                    {
                        StringContent content = new StringContent(JsonConvert.SerializeObject(memberDtoWrite), Encoding.UTF8, "application/json");
                        using (var response = await httpClient.PutAsync(apiBaseAddress + id, content))
                        {
                            string apiResponse = await response.Content.ReadAsStringAsync();
                            confirmedWrite = JsonConvert.DeserializeObject<MemberDtoWrite>(apiResponse);
                        }
                    }
                }
                catch 
                {
                    return View();
                }
            }
            return RedirectToAction(nameof(Index));
            //return RedirectToAction("Index");
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            MemberDtoWrite memberDtoWrite = new MemberDtoWrite();
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync(apiBaseAddress + id))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    memberDtoWrite = JsonConvert.DeserializeObject<MemberDtoWrite>(apiResponse);
                }
            }
            return View(memberDtoWrite);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id, IFormCollection collection)
        {
            MemberDtoWrite memberDtoWrite = new MemberDtoWrite();
            if (ModelState.IsValid)
            {
                try
                {
                    using (var httpClient = new HttpClient())
                    {
                        using (var response = await httpClient.DeleteAsync(apiBaseAddress + id))
                        {
                            string apiResponse = await response.Content.ReadAsStringAsync();
                        }
                    }
                }
                catch
                {
                    return View();
                }
            }
            return RedirectToAction(nameof(Index));
        }
    }
}
